#!/bin/bash

APP_DIR="/root/Amirho3in_GsM_VPN"
LOG_FILE="/var/log/amirho3in-vpn.log"
PID_FILE="/var/run/amirho3in-vpn.pid"
BACKUP_DIR="/root/backups"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a $LOG_FILE
}

backup_before_shutdown() {
    log "🔄 بکاپ قبل از خاموشی..."
    mkdir -p $BACKUP_DIR
    backup_file="$BACKUP_DIR/backup_before_shutdown_$(date +%Y%m%d_%H%M%S).db"
    
    if [ -f "$APP_DIR/vpn.db" ]; then
        cp "$APP_DIR/vpn.db" "$backup_file"
        log "✅ بکاپ گرفته شد: $backup_file"
        gzip "$backup_file"
    fi
}

start_app() {
    log "▶️ شروع برنامه..."
    cd $APP_DIR
    python3 main.py >> $LOG_FILE 2>&1 &
    echo $! > $PID_FILE
    log "✅ برنامه با PID $! شروع شد"
}

stop_app() {
    log "⏹️ توقف برنامه..."
    if [ -f $PID_FILE ]; then
        pid=$(cat $PID_FILE)
        kill -15 $pid 2>/dev/null
        sleep 5
        rm -f $PID_FILE
    fi
    backup_before_shutdown
}

case "$1" in
    start) start_app ;;
    stop) stop_app ;;
    restart) stop_app; sleep 3; start_app ;;
    *) echo "استفاده: $0 {start|stop|restart}" ;;
esac
