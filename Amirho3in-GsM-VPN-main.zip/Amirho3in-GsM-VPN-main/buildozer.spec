[app]

title = Amirho3in_GsM VPN
package.name = amirho3invpn
package.domain = com.amirho3in.vpn

source.dir = .
source.include_exts = py,png,jpg,kv,json,ttf

version = 4.0.0

requirements = python3,kivy,openssl,requests,android,schedule

icon.filename = %(source.dir)s/assets/icon.png
orientation = portrait

fullscreen = 0
android.permissions = INTERNET,ACCESS_NETWORK_STATE,FOREGROUND_SERVICE

android.api = 33
android.minapi = 21
android.ndk = 25b
android.accept_sdk_license = True
android.gradle_dependencies = 'com.github.2dust:AndroidLibV2rayLite:2.0.0'
android.archs = arm64-v8a

log_level = 2
warn_on_root = 1
