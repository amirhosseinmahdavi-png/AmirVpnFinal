#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Amirho3in_GsM VPN - نسخه نهایی بدون نقص
تمامی حقوق محفوظ است - پشتیبانی: @Amirho3inGsmad
"""

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.image import Image
from kivy.uix.popup import Popup
from kivy.uix.spinner import Spinner
from kivy.uix.checkbox import CheckBox
from kivy.uix.switch import Switch
from kivy.uix.tabbedpanel import TabbedPanel, TabbedPanelHeader
from kivy.core.window import Window
from kivy.clock import Clock
from kivy.utils import platform
from kivy.animation import Animation
from kivy.metrics import dp
from kivy.graphics import Color, Rectangle, RoundedRectangle
from kivy.storage.jsonstore import JsonStore

import sqlite3
import json
import os
import hashlib
import uuid
import threading
import time
import subprocess
import requests
import zipfile
import shutil
import schedule
import signal
import sys
from datetime import datetime, timedelta

# ==================== تنظیمات ثابت ====================

# پالت رنگی پایه
BASE_COLORS = {
    'primary': '#6366F1',
    'primary_dark': '#4F46E5',
    'secondary': '#8B5CF6',
    'success': '#10B981',
    'warning': '#F59E0B',
    'danger': '#EF4444',
    'background': '#0F172A',
    'surface': '#1E293B',
    'surface_light': '#334155',
    'text': '#F8FAFC',
    'text_secondary': '#94A3B8',
    'border': '#2D3748'
}

COLORS = BASE_COLORS.copy()

# اطلاعات ثابت برنامه
APP_NAME = "Amirho3in_GsM VPN"
APP_VERSION = "4.0.0"
ADMIN_USERNAME = "Naieb1"
ADMIN_PASSWORD = "Gsm@137013811392"
SUPPORT_LINK = "https://t.me/Amirho3inGsmad"
UPDATE_SERVER_IP = "5.9.166.246"
UPDATE_SERVER_PORT = "8000"

# تعرفه‌های اشتراک
SUBSCRIPTION_PRICES = {
    'monthly': 100000,
    'quarterly': 250000,
    'biannual': 480000,
    'yearly': 980000
}

SUBSCRIPTION_DAYS = {
    'monthly': 30,
    'quarterly': 90,
    'biannual': 180,
    'yearly': 365
}

# اطلاعات ربات تلگرام - اینو با اطلاعات خودت عوض کن
TELEGRAM_BOT_TOKEN = "8095124745:AAHFBwG4MbKAay3HCN_zmOn3f6BWBsEd-lw"  # از @BotFather بگیر
TELEGRAM_CHAT_ID = "5620793693"  # از @userinfobot بگیر

# ==================== کلاس مدیریت زبان ====================

class LanguageManager:
    """مدیریت زبان‌های برنامه (فارسی/انگلیسی)"""
    
    def __init__(self):
        self.current_lang = 'fa'
        self.strings = {}
        self.load_language(self.current_lang)
    
    def load_language(self, lang):
        """بارگذاری فایل زبان"""
        try:
            lang_file = f"assets/lang/{lang}.json"
            if os.path.exists(lang_file):
                with open(lang_file, 'r', encoding='utf-8') as f:
                    self.strings = json.load(f)
                self.current_lang = lang
                return True
        except Exception as e:
            print(f"خطا در بارگذاری زبان: {e}")
        return False
    
    def get(self, key, default=''):
        """دریافت متن بر اساس کلید"""
        return self.strings.get(key, default)
    
    def toggle_language(self):
        """تغییر زبان بین فارسی و انگلیسی"""
        new_lang = 'en' if self.current_lang == 'fa' else 'fa'
        self.load_language(new_lang)
        return self.current_lang

# ==================== کلاس مدیریت تم ====================

class ThemeManager:
    """مدیریت تم تاریک/روشن"""
    
    def __init__(self):
        self.is_dark = True
        self.load_theme()
    
    def load_theme(self):
        """بارگذاری تم ذخیره شده"""
        try:
            store = JsonStore('theme.json')
            if store.exists('theme'):
                self.is_dark = store.get('theme')['is_dark']
        except:
            pass
        self.apply_theme()
    
    def save_theme(self):
        """ذخیره تم"""
        try:
            store = JsonStore('theme.json')
            store.put('theme', is_dark=self.is_dark)
        except:
            pass
    
    def toggle_theme(self):
        """تغییر تم"""
        self.is_dark = not self.is_dark
        self.apply_theme()
        self.save_theme()
    
    def apply_theme(self):
        """اعمال تم"""
        global COLORS
        if self.is_dark:
            COLORS = BASE_COLORS.copy()
            Window.clearcolor = (0.05, 0.05, 0.1, 1)
        else:
            COLORS = {
                'primary': '#4F46E5',
                'primary_dark': '#6366F1',
                'secondary': '#8B5CF6',
                'success': '#059669',
                'warning': '#D97706',
                'danger': '#DC2626',
                'background': '#F3F4F6',
                'surface': '#FFFFFF',
                'surface_light': '#E5E7EB',
                'text': '#111827',
                'text_secondary': '#6B7280',
                'border': '#D1D5DB'
            }
            Window.clearcolor = (0.95, 0.95, 0.95, 1)

# ==================== کلاس مدیریت سیگنال‌ها ====================

class SignalHandler:
    """مدیریت سیگنال‌های سیستمی برای خاموشی تمیز"""
    
    def __init__(self, telegram_backup):
        self.telegram_backup = telegram_backup
        self.running = True
        
        # نصب هندلر برای سیگنال‌های خاموشی
        signal.signal(signal.SIGTERM, self.signal_handler)
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGHUP, self.signal_handler)
    
    def signal_handler(self, signum, frame):
        """وقتی سیگنال خاموشی دریافت میشه"""
        print(f"📡 سیگنال {signum} دریافت شد - در حال خاموشی تمیز...")
        self.running = False
        
        # بکاپ قبل از خاموشی
        self.telegram_backup.create_backup_and_send(shutdown=True)
        
        print("✅ خاموشی تمیز انجام شد")
        sys.exit(0)

# ==================== کلاس ارسال خودکار بکاپ به تلگرام ====================

class TelegramBackup:
    """ارسال خودکار بکاپ به ربات تلگرام هر ۱۲ ساعت"""
    
    def __init__(self, db_manager, bot_token, chat_id):
        self.db = db_manager
        self.bot_token = bot_token
        self.chat_id = chat_id
        self.api_url = f"https://api.telegram.org/bot{bot_token}"
        self.last_backup_time = None
        
        # شروع ترد بکاپ خودکار
        self.start_auto_backup()
        print("✅ ارسال خودکار بکاپ به تلگرام فعال شد (هر ۱۲ ساعت)")
    
    def send_message(self, text, parse_mode='HTML'):
        """ارسال پیام به تلگرام"""
        try:
            url = f"{self.api_url}/sendMessage"
            data = {
                "chat_id": self.chat_id,
                "text": text,
                "parse_mode": parse_mode
            }
            response = requests.post(url, json=data, timeout=10)
            return response.json()
        except Exception as e:
            print(f"❌ خطا در ارسال پیام: {e}")
            return None
    
    def send_file(self, file_path, caption=""):
        """ارسال فایل به تلگرام"""
        try:
            url = f"{self.api_url}/sendDocument"
            with open(file_path, 'rb') as f:
                files = {'document': f}
                data = {'chat_id': self.chat_id, 'caption': caption}
                response = requests.post(url, files=files, data=data, timeout=30)
            return response.json()
        except Exception as e:
            print(f"❌ خطا در ارسال فایل: {e}")
            return None
    
    def create_backup_and_send(self, manual=False, shutdown=False):
        """ایجاد بکاپ و ارسال به تلگرام"""
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            
            # ایجاد بکاپ
            backup_file = self.db.create_backup()
            
            if not backup_file or not os.path.exists(backup_file):
                print("❌ خطا در ایجاد بکاپ")
                return False
            
            # گرفتن آمار
            stats = self.db.get_stats()
            
            # ساخت کپشن
            if shutdown:
                caption = f"""🔌 <b>بکاپ قبل از خاموشی - {APP_NAME}</b>
━━━━━━━━━━━━━━━━
📅 {datetime.now().strftime('%Y/%m/%d - %H:%M:%S')}

👥 کاربران: {stats['total_users']} (✅ {stats['active_users']} فعال)
🌍 سرورها: {stats['active_servers']}
📢 تبلیغات: {stats['ads']}

💾 حجم: {os.path.getsize(backup_file) / (1024*1024):.2f} MB
🔄 خاموشی سیستم - بکاپ گرفته شد"""
            elif manual:
                caption = f"""📦 <b>بکاپ دستی - {APP_NAME}</b>
━━━━━━━━━━━━━━━━
📅 {datetime.now().strftime('%Y/%m/%d - %H:%M:%S')}

👥 کاربران: {stats['total_users']} (✅ {stats['active_users']} فعال)
🌍 سرورها: {stats['active_servers']}
📢 تبلیغات: {stats['ads']}

💾 حجم: {os.path.getsize(backup_file) / (1024*1024):.2f} MB
🔄 درخواست دستی توسط ادمین"""
            else:
                caption = f"""📦 <b>بکاپ خودکار - {APP_NAME}</b>
━━━━━━━━━━━━━━━━
📅 {datetime.now().strftime('%Y/%m/%d - %H:%M:%S')}

👥 کاربران: {stats['total_users']} (✅ {stats['active_users']} فعال)
🌍 سرورها: {stats['active_servers']}
📢 تبلیغات: {stats['ads']}

💾 حجم: {os.path.getsize(backup_file) / (1024*1024):.2f} MB
🔄 بکاپ خودکار - هر ۱۲ ساعت"""
            
            # ارسال فایل
            result = self.send_file(backup_file, caption)
            
            if result and result.get('ok'):
                print(f"✅ بکاپ ارسال شد: {os.path.basename(backup_file)}")
                self.last_backup_time = datetime.now()
                return True
            else:
                print("❌ خطا در ارسال بکاپ به تلگرام")
                return False
                
        except Exception as e:
            print(f"❌ خطا در ارسال بکاپ: {e}")
            return False
    
    def auto_backup_worker(self):
        """کارگر بکاپ خودکار"""
        while True:
            try:
                now = datetime.now()
                
                # ارسال هر ۱۲ ساعت (ساعت ۳:۰۰ و ۱۵:۰۰)
                if now.hour in [3, 15] and now.minute < 5:
                    print(f"⏰ زمان بکاپ خودکار: {now.strftime('%Y-%m-%d %H:%M:%S')}")
                    self.create_backup_and_send(manual=False, shutdown=False)
                    time.sleep(60)  # جلوگیری از ارسال مجدد
                
                time.sleep(30)  # چک هر ۳۰ ثانیه
            except Exception as e:
                print(f"❌ خطا در بکاپ خودکار: {e}")
                time.sleep(60)
    
    def start_auto_backup(self):
        """شروع بکاپ خودکار در یک ترد جدا"""
        backup_thread = threading.Thread(target=self.auto_backup_worker, daemon=True)
        backup_thread.start()

# ==================== کلاس مدیریت مصرف ====================

class UsageManager:
    """مدیریت مصرف حجمی کاربران"""
    
    def __init__(self, db_path):
        self.db_path = db_path
        self.init_usage_table()
    
    def get_connection(self):
        return sqlite3.connect(self.db_path)
    
    def init_usage_table(self):
        """ایجاد جدول مصرف"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                date TEXT NOT NULL,
                upload INTEGER DEFAULT 0,
                download INTEGER DEFAULT 0,
                total INTEGER DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def add_usage(self, user_id, upload, download):
        """اضافه کردن مصرف"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        today = datetime.now().strftime('%Y-%m-%d')
        
        cursor.execute('''
            INSERT INTO usage (user_id, date, upload, download, total)
            VALUES (?, ?, ?, ?, ?)
        ''', (user_id, today, upload, download, upload + download))
        
        conn.commit()
        conn.close()
    
    def get_user_usage(self, user_id):
        """گرفتن مصرف کاربر"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT SUM(upload), SUM(download), SUM(total)
            FROM usage WHERE user_id = ?
        ''', (user_id,))
        
        result = cursor.fetchone()
        conn.close()
        
        return {
            'upload': result[0] or 0,
            'download': result[1] or 0,
            'total': result[2] or 0
        }
    
    def get_monthly_usage(self, user_id):
        """مصرف ماهانه کاربر"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        month_start = datetime.now().replace(day=1).strftime('%Y-%m-%d')
        
        cursor.execute('''
            SELECT SUM(total) FROM usage
            WHERE user_id = ? AND date >= ?
        ''', (user_id, month_start))
        
        result = cursor.fetchone()
        conn.close()
        
        return result[0] or 0

# ==================== کلاس انتخاب خودکار سرور ====================

class AutoServerSelector:
    """انتخاب خودکار بهترین سرور"""
    
    def __init__(self, db_manager):
        self.db = db_manager
        self.best_server = None
    
    def find_best_server(self):
        """پیدا کردن بهترین سرور بر اساس پینگ و بار"""
        servers = self.db.get_all_servers()
        if not servers:
            return None
        
        best_score = float('inf')
        best_server = None
        
        for server in servers:
            if not server['is_active']:
                continue
            
            # پینگ
            ping = server.get('ping', 999)
            
            # محاسبه امتیاز (پینگ کمتر = بهتر)
            score = ping
            
            if score < best_score:
                best_score = score
                best_server = server
        
        return best_server

# ==================== کلاس مدیریت آپدیت با IP مستقیم ====================

class UpdateManager:
    """مدیریت آپدیت درون‌برنامه‌ای با IP مستقیم"""
    
    def __init__(self, app):
        self.app = app
        self.current_version = APP_VERSION
        self.update_url = f"http://{UPDATE_SERVER_IP}:{UPDATE_SERVER_PORT}/latest.json"
        self.apk_base_url = f"http://{UPDATE_SERVER_IP}:{UPDATE_SERVER_PORT}/"
    
    def check_for_update(self):
        """بررسی وجود آپدیت جدید"""
        try:
            print(f"🔄 بررسی آپدیت از {self.update_url}")
            response = requests.get(
                self.update_url,
                timeout=10,
                headers={"User-Agent": f"{APP_NAME}/{self.current_version}"}
            )
            
            if response.status_code == 200:
                data = response.json()
                server_version = data.get('version', '0')
                
                print(f"📦 ورژن سرور: {server_version}, ورژن برنامه: {self.current_version}")
                
                # مقایسه ورژن‌ها
                if self.compare_versions(server_version, self.current_version) > 0:
                    self.show_update_popup(data)
                    return True
                else:
                    print("✅ برنامه به‌روز است")
            else:
                print(f"❌ خطا در دریافت آپدیت: کد {response.status_code}")
                
        except requests.exceptions.ConnectionError:
            print("❌ خطا در اتصال به سرور آپدیت")
        except requests.exceptions.Timeout:
            print("❌ زمان اتصال به سرور آپدیت تمام شد")
        except Exception as e:
            print(f"❌ خطای غیرمنتظره: {e}")
        
        return False
    
    def compare_versions(self, v1, v2):
        """مقایسه دو ورژن (مثلاً 4.1.0 با 4.0.0)"""
        v1_parts = [int(x) for x in v1.split('.')]
        v2_parts = [int(x) for x in v2.split('.')]
        
        for i in range(max(len(v1_parts), len(v2_parts))):
            v1_val = v1_parts[i] if i < len(v1_parts) else 0
            v2_val = v2_parts[i] if i < len(v2_parts) else 0
            
            if v1_val > v2_val:
                return 1
            elif v1_val < v2_val:
                return -1
        
        return 0
    
    def show_update_popup(self, update_info):
        """نمایش پاپ‌آپ آپدیت با لینک مستقیم از IP"""
        content = BoxLayout(orientation='vertical', spacing=15, padding=15)
        
        # عنوان
        title = Label(
            text=f"📦 نسخه جدید {update_info.get('version', '')}",
            size_hint_y=None,
            height=40,
            font_size='18sp',
            bold=True,
            color=COLORS['primary']
        )
        content.add_widget(title)
        
        # توضیحات تغییرات
        changes_text = update_info.get('changes', 'تغییرات جدید اعمال شده است')
        changes_label = Label(
            text=changes_text,
            size_hint_y=None,
            height=120,
            color=COLORS['text'],
            halign='center'
        )
        content.add_widget(changes_label)
        
        # دکمه‌ها
        btn_box = BoxLayout(size_hint_y=None, height=50, spacing=10)
        
        def download_update(btn):
            # ساخت لینک دانلود APK
            version = update_info.get('version', '4.1.0')
            download_url = f"{self.apk_base_url}amirho3invpn-{version}.apk"
            
            import webbrowser
            webbrowser.open(download_url)
            popup.dismiss()
            
            # اطلاع به کاربر
            self.show_download_notice()
        
        def later(btn):
            popup.dismiss()
        
        download_btn = Button(
            text='📥 دانلود آپدیت',
            background_normal='',
            background_color=COLORS['success'],
            size_hint=(0.6, 1)
        )
        download_btn.bind(on_press=download_update)
        
        later_btn = Button(
            text='⏰ بعداً',
            background_normal='',
            background_color=COLORS['surface_light'],
            size_hint=(0.4, 1)
        )
        later_btn.bind(on_press=later)
        
        btn_box.add_widget(download_btn)
        btn_box.add_widget(later_btn)
        content.add_widget(btn_box)
        
        # نکته امنیتی
        note_label = Label(
            text="🔒 دانلود از سرور اختصاصی",
            size_hint_y=None,
            height=30,
            color=COLORS['text_secondary'],
            font_size='12sp'
        )
        content.add_widget(note_label)
        
        popup = Popup(
            title='🔄 آپدیت جدید',
            title_color=COLORS['text'],
            title_size='18sp',
            content=content,
            size_hint=(0.85, 0.6)
        )
        popup.open()
    
    def show_download_notice(self):
        """نمایش پیام بعد از دانلود"""
        content = BoxLayout(orientation='vertical', spacing=10, padding=10)
        
        content.add_widget(Label(
            text="✅ لینک دانلود در مرورگر باز شد",
            color=COLORS['success'],
            size_hint_y=None,
            height=40
        ))
        
        content.add_widget(Label(
            text="پس از دانلود، فایل APK را نصب کنید.\nاطلاعات کاربری شما حفظ می‌شود.",
            color=COLORS['text'],
            size_hint_y=None,
            height=60
        ))
        
        btn = Button(
            text='باشه',
            size_hint_y=None,
            height=40,
            background_normal='',
            background_color=COLORS['primary']
        )
        
        popup = Popup(
            title='📥 دانلود',
            title_color=COLORS['text'],
            content=content,
            size_hint=(0.7, 0.4)
        )
        
        btn.bind(on_press=popup.dismiss)
        content.add_widget(btn)
        
        popup.open()

# ==================== کلاس مدیریت دیتابیس ====================

class DatabaseManager:
    def __init__(self):
        if platform == 'android':
            from android.storage import app_storage_path
            self.db_path = '/data/data/org.amirho3in.vpn/files/vpn.db'
        else:
            self.db_path = 'vpn.db'
        
        self.usage_manager = UsageManager(self.db_path)
        self.init_database()
    
    def get_connection(self):
        return sqlite3.connect(self.db_path)
    
    def init_database(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # جدول کاربران
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                fullname TEXT,
                email TEXT,
                phone TEXT,
                is_admin INTEGER DEFAULT 0,
                subscription_type TEXT DEFAULT 'monthly',
                subscription_start TEXT,
                subscription_end TEXT,
                is_active INTEGER DEFAULT 1,
                created_at TEXT,
                last_login TEXT,
                last_device_id TEXT,
                data_limit INTEGER DEFAULT 0
            )
        ''')
        
        # جدول نشست‌ها (تک کاربره)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                device_id TEXT NOT NULL,
                session_token TEXT NOT NULL,
                login_time TEXT NOT NULL,
                last_activity TEXT,
                is_active INTEGER DEFAULT 1,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # جدول سرورها (با لینک مخفی)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS servers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                ip_address TEXT NOT NULL,
                location TEXT,
                flag_icon TEXT DEFAULT '🌍',
                protocol TEXT DEFAULT 'vmess',
                port INTEGER DEFAULT 443,
                vmess_link TEXT,
                vless_link TEXT,
                ping INTEGER DEFAULT 0,
                is_active INTEGER DEFAULT 1,
                created_at TEXT
            )
        ''')
        
        # جدول تبلیغات
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS ads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                image_path TEXT,
                link_url TEXT,
                position TEXT DEFAULT 'banner',
                is_active INTEGER DEFAULT 1,
                views INTEGER DEFAULT 0,
                clicks INTEGER DEFAULT 0,
                created_at TEXT
            )
        ''')
        
        # جدول تنظیمات
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at TEXT
            )
        ''')
        
        # جدول بکاپ‌ها
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS backups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT NOT NULL,
                size INTEGER,
                created_at TEXT,
                status TEXT DEFAULT 'success'
            )
        ''')
        
        conn.commit()
        
        # ایجاد کاربر ادمین پیش‌فرض
        cursor.execute(f"SELECT * FROM users WHERE username = '{ADMIN_USERNAME}'")
        if not cursor.fetchone():
            self.create_user(
                username=ADMIN_USERNAME,
                password=ADMIN_PASSWORD,
                fullname='مدیر سیستم',
                is_admin=1,
                subscription_type='yearly'
            )
            print(f"✅ کاربر ادمین ساخته شد: {ADMIN_USERNAME} / {ADMIN_PASSWORD}")
        
        # ایجاد سرورهای نمونه
        cursor.execute("SELECT * FROM servers")
        if not cursor.fetchone():
            self.add_server(
                name='آلمان - فرانکفورت',
                ip_address='185.165.123.45',
                location='فرانکفورت، آلمان',
                flag_icon='🇩🇪',
                vmess_link='vmess://eyJhZGQiOiIxODUuMTY1LjEyMy40NSIsInBvcnQiOiI0NDMiLCJpZCI6IjIzNDVmNjc4LTk4NzYtNDMyMS1hY2Y0LTEyMzQ1Njc4OTBhYiIsImFpZCI6IjAiLCJuZXQiOiJ3cyIsInR5cGUiOiJub25lIiwiaG9zdCI6IiIsInBhdGgiOiIvIiwidGxzIjoidGxzIn0='
            )
            self.add_server(
                name='ترکیه - استانبول',
                ip_address='195.201.78.90',
                location='استانبول، ترکیه',
                flag_icon='🇹🇷',
                vmess_link='vmess://eyJhZGQiOiIxOTUuMjAxLjc4LjkwIiwicG9ydCI6IjQ0MyIsImlkIjoiMzQ1Njc4OTAtYWJjZC1lZmdoLWlqa2wtbW5vcHFyc3R1dnd4IiwiYWlkIjoiMCIsIm5ldCI6IndzIiwidHlwZSI6Im5vbmUiLCJob3N0IjoiIiwicGF0aCI6Ii8iLCJ0bHMiOiJ0bHMifQ=='
            )
            print("✅ سرورهای نمونه ساخته شدند")
        
        conn.close()
    
    def hash_password(self, password):
        return hashlib.sha256(password.encode()).hexdigest()
    
    def generate_device_id(self):
        import uuid
        device_info = f"{uuid.uuid4()}-{platform}-{datetime.now().timestamp()}"
        return hashlib.md5(device_info.encode()).hexdigest()
    
    # ========== مدیریت کاربران ==========
    
    def create_user(self, username, password, fullname='', email='', phone='', 
                    is_admin=0, subscription_type='monthly', data_limit=0):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        days = SUBSCRIPTION_DAYS.get(subscription_type, 30)
        end = (datetime.now() + timedelta(days=days)).strftime('%Y-%m-%d %H:%M:%S')
        
        try:
            cursor.execute('''
                INSERT INTO users 
                (username, password, fullname, email, phone, is_admin, 
                 subscription_type, subscription_start, subscription_end, created_at, data_limit)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (username, self.hash_password(password), fullname, email, phone, 
                  is_admin, subscription_type, now, end, now, data_limit))
            
            conn.commit()
            user_id = cursor.lastrowid
            conn.close()
            return user_id
        except sqlite3.IntegrityError:
            conn.close()
            return None
    
    def check_login(self, username, password, device_id=None):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        hashed = self.hash_password(password)
        cursor.execute('''
            SELECT id, username, fullname, is_admin, subscription_type, 
                   subscription_end, is_active, last_device_id, data_limit
            FROM users WHERE username = ? AND password = ?
        ''', (username, hashed))
        
        user = cursor.fetchone()
        
        if user:
            user_id = user[0]
            
            if not user[6]:
                conn.close()
                return {'success': False, 'error': 'کاربر غیرفعال است'}
            
            end_date = datetime.strptime(user[5], '%Y-%m-%d %H:%M:%S')
            if datetime.now() > end_date:
                conn.close()
                return {'success': False, 'error': 'اشتراک به پایان رسیده'}
            
            last_device = user[7]
            if last_device and last_device != device_id and user[3] == 0:
                cursor.execute('''
                    SELECT * FROM sessions 
                    WHERE user_id = ? AND device_id = ? AND is_active = 1
                ''', (user_id, last_device))
                
                active_session = cursor.fetchone()
                if active_session:
                    conn.close()
                    return {
                        'success': False, 
                        'error': 'کاربر با دستگاه دیگری وارد شده است',
                        'requires_force': True,
                        'user_id': user_id
                    }
            
            now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            cursor.execute('''
                UPDATE users SET last_login = ?, last_device_id = ? 
                WHERE id = ?
            ''', (now, device_id, user_id))
            
            conn.commit()
            
            session_token = str(uuid.uuid4())
            cursor.execute('''
                INSERT INTO sessions (user_id, device_id, session_token, login_time, is_active)
                VALUES (?, ?, ?, ?, 1)
            ''', (user_id, device_id, session_token, now))
            
            conn.commit()
            conn.close()
            
            # دریافت مصرف
            usage = self.usage_manager.get_user_usage(user_id)
            
            return {
                'success': True,
                'user': {
                    'id': user_id,
                    'username': user[1],
                    'fullname': user[2] or user[1],
                    'is_admin': user[3],
                    'subscription_type': user[4],
                    'subscription_end': user[5],
                    'data_limit': user[8],
                    'usage': usage['total']
                },
                'session_token': session_token
            }
        
        conn.close()
        return {'success': False, 'error': 'نام کاربری یا رمز اشتباه است'}
    
    def force_end_session(self, user_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE sessions SET is_active = 0 
            WHERE user_id = ? AND is_active = 1
        ''', (user_id,))
        conn.commit()
        conn.close()
        return True
    
    def get_all_users(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, username, fullname, is_admin, subscription_type, 
                   subscription_end, is_active, created_at, last_login, last_device_id, data_limit
            FROM users ORDER BY id DESC
        ''')
        
        users = cursor.fetchall()
        conn.close()
        
        result = []
        for u in users:
            usage = self.usage_manager.get_user_usage(u[0])
            result.append({
                'id': u[0], 'username': u[1], 'fullname': u[2],
                'is_admin': u[3], 'subscription_type': u[4],
                'subscription_end': u[5], 'is_active': u[6],
                'created_at': u[7], 'last_login': u[8], 'last_device': u[9],
                'data_limit': u[10], 'usage': usage['total']
            })
        return result
    
    def delete_user(self, user_id):
        self.force_end_session(user_id)
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        cursor.execute("DELETE FROM sessions WHERE user_id = ?", (user_id,))
        cursor.execute("DELETE FROM usage WHERE user_id = ?", (user_id,))
        conn.commit()
        conn.close()
        return True
    
    def update_user(self, user_id, data):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        updates = []
        values = []
        
        if 'username' in data:
            updates.append("username = ?")
            values.append(data['username'])
        
        if 'password' in data:
            updates.append("password = ?")
            values.append(self.hash_password(data['password']))
        
        if 'fullname' in data:
            updates.append("fullname = ?")
            values.append(data['fullname'])
        
        if 'data_limit' in data:
            updates.append("data_limit = ?")
            values.append(data['data_limit'])
        
        if updates:
            values.append(user_id)
            query = f"UPDATE users SET {', '.join(updates)} WHERE id = ?"
            cursor.execute(query, values)
        
        conn.commit()
        conn.close()
        return True
    
    def update_user_subscription(self, user_id, subscription_type, days=None):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        if days:
            cursor.execute("SELECT subscription_end FROM users WHERE id = ?", (user_id,))
            current_end = cursor.fetchone()[0]
            if current_end:
                new_end = datetime.strptime(current_end, '%Y-%m-%d %H:%M:%S') + timedelta(days=days)
            else:
                new_end = datetime.now() + timedelta(days=days)
        else:
            days = SUBSCRIPTION_DAYS.get(subscription_type, 30)
            new_end = datetime.now() + timedelta(days=days)
        
        cursor.execute('''
            UPDATE users 
            SET subscription_type = ?, subscription_end = ?, is_active = 1
            WHERE id = ?
        ''', (subscription_type, new_end.strftime('%Y-%m-%d %H:%M:%S'), user_id))
        
        conn.commit()
        conn.close()
        return True
    
    def toggle_user_status(self, user_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT is_active FROM users WHERE id = ?", (user_id,))
        current = cursor.fetchone()[0]
        
        cursor.execute("UPDATE users SET is_active = ? WHERE id = ?", (0 if current else 1, user_id))
        
        if current:
            self.force_end_session(user_id)
        
        conn.commit()
        conn.close()
        return True
    
    # ========== مدیریت سرورها ==========
    
    def add_server(self, name, ip_address, location, flag_icon='🌍', 
                   protocol='vmess', port=443, vmess_link='', vless_link=''):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        cursor.execute('''
            INSERT INTO servers 
            (name, ip_address, location, flag_icon, protocol, port, 
             vmess_link, vless_link, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (name, ip_address, location, flag_icon, protocol, port, 
              vmess_link, vless_link, now))
        
        conn.commit()
        server_id = cursor.lastrowid
        conn.close()
        return server_id
    
    def get_all_servers(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, name, ip_address, location, flag_icon, protocol, 
                   port, ping, is_active, vmess_link, vless_link
            FROM servers ORDER BY is_active DESC, ping ASC
        ''')
        
        servers = cursor.fetchall()
        conn.close()
        
        result = []
        for s in servers:
            result.append({
                'id': s[0], 'name': s[1], 'ip': s[2], 'location': s[3],
                'flag': s[4], 'protocol': s[5], 'port': s[6],
                'ping': s[7], 'is_active': s[8], 
                'has_vmess': bool(s[9]), 'has_vless': bool(s[10])
            })
        return result
    
    def get_server_config(self, server_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT vmess_link, vless_link, protocol FROM servers WHERE id = ?", (server_id,))
        server = cursor.fetchone()
        conn.close()
        
        return {
            'vmess': server[0] if server else None,
            'vless': server[1] if server else None,
            'protocol': server[2] if server else 'vmess'
        }
    
    def delete_server(self, server_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM servers WHERE id = ?", (server_id,))
        conn.commit()
        conn.close()
        return True
    
    def toggle_server_status(self, server_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT is_active FROM servers WHERE id = ?", (server_id,))
        current = cursor.fetchone()[0]
        
        cursor.execute("UPDATE servers SET is_active = ? WHERE id = ?", (0 if current else 1, server_id))
        conn.commit()
        conn.close()
        return True
    
    def ping_server(self, ip_address):
        try:
            param = '-n' if platform.system().lower() == 'windows' else '-c'
            result = subprocess.run(
                ['ping', param, '1', ip_address],
                capture_output=True,
                text=True,
                timeout=3
            )
            
            if result.returncode == 0:
                import re
                match = re.search(r'time[=<](\d+\.?\d*)', result.stdout)
                if match:
                    return int(float(match.group(1)))
            return 999
        except:
            return 999
    
    # ========== مدیریت تبلیغات ==========
    
    def get_all_ads(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM ads WHERE is_active = 1")
        ads = cursor.fetchall()
        conn.close()
        
        result = []
        for a in ads:
            result.append({
                'id': a[0], 'title': a[1], 'image': a[2],
                'link': a[3], 'position': a[4],
                'views': a[6], 'clicks': a[7]
            })
        return result
    
    def add_ad(self, title, image_path, link_url, position='banner'):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        cursor.execute('''
            INSERT INTO ads (title, image_path, link_url, position, created_at)
            VALUES (?, ?, ?, ?, ?)
        ''', (title, image_path, link_url, position, now))
        
        conn.commit()
        ad_id = cursor.lastrowid
        conn.close()
        return ad_id
    
    def increment_ad_view(self, ad_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE ads SET views = views + 1 WHERE id = ?", (ad_id,))
        conn.commit()
        conn.close()
    
    def increment_ad_click(self, ad_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE ads SET clicks = clicks + 1 WHERE id = ?", (ad_id,))
        conn.commit()
        conn.close()
    
    # ========== آمار ==========
    
    def get_stats(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM users WHERE is_active = 1")
        active_users = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM servers WHERE is_active = 1")
        active_servers = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM users WHERE is_admin = 1")
        admins = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM sessions WHERE is_active = 1")
        active_sessions = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM ads")
        ads = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM backups")
        backups = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            'total_users': total_users,
            'active_users': active_users,
            'active_servers': active_servers,
            'admins': admins,
            'active_sessions': active_sessions,
            'ads': ads,
            'backups': backups
        }
    
    def check_subscription(self, user_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT subscription_end, is_active FROM users WHERE id = ?", (user_id,))
        result = cursor.fetchone()
        conn.close()
        
        if not result:
            return False
        
        end_date = datetime.strptime(result[0], '%Y-%m-%d %H:%M:%S')
        return datetime.now() < end_date and result[1] == 1
    
    def get_user_days_left(self, user_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT subscription_end FROM users WHERE id = ?", (user_id,))
        result = cursor.fetchone()
        conn.close()
        
        if result and result[0]:
            end_date = datetime.strptime(result[0], '%Y-%m-%d %H:%M:%S')
            days = (end_date - datetime.now()).days
            hours = ((end_date - datetime.now()).seconds // 3600)
            return max(0, days), max(0, hours)
        return 0, 0
    
    # ========== بکاپ و بازیابی ==========
    
    def create_backup(self):
        """ایجاد بکاپ از دیتابیس"""
        import zipfile
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_dir = 'backups'
        os.makedirs(backup_dir, exist_ok=True)
        
        backup_file = os.path.join(backup_dir, f'backup_{timestamp}.db')
        shutil.copy2(self.db_path, backup_file)
        
        # فشرده‌سازی
        zip_file = f"{backup_file}.zip"
        with zipfile.ZipFile(zip_file, 'w', zipfile.ZIP_DEFLATED) as zf:
            zf.write(backup_file, 'vpn.db')
        
        os.remove(backup_file)
        
        # ذخیره در دیتابیس
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO backups (filename, size, created_at, status)
            VALUES (?, ?, ?, ?)
        ''', (os.path.basename(zip_file), os.path.getsize(zip_file), timestamp, 'success'))
        conn.commit()
        conn.close()
        
        return zip_file
    
    def restore_backup(self, backup_file):
        """بازیابی از بکاپ"""
        import zipfile
        
        try:
            temp_dir = 'temp_restore'
            os.makedirs(temp_dir, exist_ok=True)
            
            with zipfile.ZipFile(backup_file, 'r') as zf:
                zf.extractall(temp_dir)
            
            extracted_db = os.path.join(temp_dir, 'vpn.db')
            if os.path.exists(extracted_db):
                # بکاپ از دیتابیس فعلی
                current_backup = self.create_backup()
                
                # جایگزینی
                shutil.copy2(extracted_db, self.db_path)
                
                shutil.rmtree(temp_dir)
                return True, current_backup
            else:
                shutil.rmtree(temp_dir)
                return False, None
                
        except Exception as e:
            print(f"خطا در بازیابی: {e}")
            return False, None
    
    def list_backups(self):
        """لیست بکاپ‌های موجود"""
        backup_dir = 'backups'
        if not os.path.exists(backup_dir):
            return []
        
        backups = []
        for f in sorted(os.listdir(backup_dir)):
            if f.endswith('.zip'):
                file_path = os.path.join(backup_dir, f)
                backups.append({
                    'name': f,
                    'size': os.path.getsize(file_path) / (1024 * 1024),  # MB
                    'date': datetime.fromtimestamp(os.path.getmtime(file_path)).strftime('%Y-%m-%d %H:%M:%S')
                })
        return backups

# ==================== کلاس V2RayCore ====================

class V2RayCore:
    """هسته V2Ray با پشتیبانی از VMess و VLESS"""
    
    def __init__(self):
        self.connected = False
        self.current_server = None
        self.stats = {'upload': 0, 'download': 0, 'total': 0}
        
        if platform == 'android':
            self.init_v2ray_library()
    
    def init_v2ray_library(self):
        """راه‌اندازی کتابخانه V2Ray اندروید"""
        try:
            from jnius import autoclass
            
            self.V2rayController = autoclass('dev.dev7.lib.v2ray.V2rayController')
            self.Context = autoclass('android.content.Context')
            self.PythonActivity = autoclass('org.kivy.android.PythonActivity')
            
            self.context = self.PythonActivity.mActivity
            self.v2ray = self.V2rayController.getInstance()
            
            return True
        except Exception as e:
            print(f"⚠️ خطا در راه‌اندازی V2Ray: {e}")
            return False
    
    def parse_vmess_link(self, vmess_link):
        """تبدیل لینک vmess به کانفیگ JSON"""
        import base64
        import re
        
        try:
            match = re.search(r'vmess://(.+)', vmess_link)
            if not match:
                return None
            
            encoded = match.group(1)
            encoded += '=' * (4 - len(encoded) % 4)
            
            decoded = base64.b64decode(encoded).decode('utf-8')
            config = json.loads(decoded)
            
            return config
        except Exception as e:
            print(f"⚠️ خطا در parse لینک vmess: {e}")
            return None
    
    def parse_vless_link(self, vless_link):
        """تبدیل لینک vless به کانفیگ JSON"""
        import urllib.parse
        
        try:
            parts = vless_link.replace('vless://', '').split('?')
            main_part = parts[0].split('@')
            uuid_part = main_part[0]
            host_port = main_part[1].split(':')
            host = host_port[0]
            port = int(host_port[1]) if len(host_port) > 1 else 443
            
            params = {}
            if len(parts) > 1:
                param_str = parts[1].split('#')[0]
                params = dict(urllib.parse.parse_qsl(param_str))
            
            config = {
                'protocol': 'vless',
                'uuid': uuid_part,
                'host': host,
                'port': port,
                'network': params.get('type', 'tcp'),
                'security': params.get('security', 'none'),
                'path': params.get('path', '/'),
                'remark': vless_link.split('#')[-1] if '#' in vless_link else ''
            }
            
            return config
        except Exception as e:
            print(f"⚠️ خطا در parse لینک vless: {e}")
            return None
    
    def connect(self, server_id, server_name, vmess_link=None, vless_link=None, protocol='vmess'):
        """اتصال به سرور V2Ray"""
        try:
            config = None
            if protocol == 'vless' and vless_link:
                config = self.parse_vless_link(vless_link)
            else:
                config = self.parse_vmess_link(vmess_link)
            
            if not config:
                return {'success': False, 'error': 'لینک معتبر نیست'}
            
            if platform == 'android':
                remark = f"{server_name} - {APP_NAME}"
                
                v2ray_config = {
                    "log": {"loglevel": "warning"},
                    "inbounds": [{
                        "port": 10808,
                        "protocol": "socks",
                        "settings": {"auth": "noauth", "udp": True}
                    }],
                    "outbounds": [{
                        "protocol": protocol,
                        "settings": {
                            "vnext": [{
                                "address": config.get("add") or config.get("host"),
                                "port": int(config.get("port", 443)),
                                "users": [{
                                    "id": config.get("id") or config.get("uuid"),
                                    "alterId": int(config.get("aid", 0)),
                                    "security": "auto"
                                }]
                            }]
                        },
                        "streamSettings": {
                            "network": config.get("net") or config.get("network", "tcp"),
                            "security": config.get("tls") or config.get("security", "none"),
                            "wsSettings": {
                                "path": config.get("path", "/")
                            } if (config.get("net") == "ws" or config.get("network") == "ws") else None
                        }
                    }]
                }
                
                self.v2ray.startV2ray(
                    self.context,
                    remark,
                    json.dumps(v2ray_config),
                    None
                )
                
                self.connected = True
                self.current_server = server_name
                
                return {'success': True, 'message': '✅ اتصال برقرار شد'}
            else:
                self.connected = True
                self.current_server = server_name
                return {'success': True, 'message': '✅ اتصال شبیه‌سازی شد'}
                
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def disconnect(self):
        """قطع اتصال"""
        try:
            if platform == 'android' and hasattr(self, 'v2ray'):
                self.v2ray.stopV2ray(self.context)
            
            self.connected = False
            self.current_server = None
            return {'success': True}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def get_status(self):
        """وضعیت فعلی اتصال"""
        return {
            'connected': self.connected,
            'server': self.current_server,
            'stats': self.stats
        }

# ==================== صفحه ورود ====================

class LoginScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.db = DatabaseManager()
        self.lang = App.get_running_app().lang
        self.device_id = self.db.generate_device_id()
        
        self.layout = BoxLayout(orientation='vertical', padding=30, spacing=15)
        
        # لوگو
        self.logo = Image(
            source='assets/icon.png',
            size_hint=(1, 0.25),
            allow_stretch=True
        )
        self.layout.add_widget(self.logo)
        
        # عنوان
        self.title = Label(
            text=f'[b]{APP_NAME}[/b]',
            markup=True,
            font_size='24sp',
            color=COLORS['primary'],
            size_hint=(1, 0.1)
        )
        self.layout.add_widget(self.title)
        
        # فیلد نام کاربری
        self.username = TextInput(
            hint_text=self.lang.get('username'),
            multiline=False,
            size_hint=(1, 0.1),
            background_color=COLORS['surface'],
            foreground_color=COLORS['text'],
            hint_text_color=COLORS['text_secondary'],
            padding=(15, 15)
        )
        self.layout.add_widget(self.username)
        
        # فیلد رمز عبور
        self.password = TextInput(
            hint_text=self.lang.get('password'),
            password=True,
            multiline=False,
            size_hint=(1, 0.1),
            background_color=COLORS['surface'],
            foreground_color=COLORS['text'],
            hint_text_color=COLORS['text_secondary'],
            padding=(15, 15)
        )
        self.layout.add_widget(self.password)
        
        # گزینه "مرا به خاطر بسپار"
        remember_box = BoxLayout(size_hint=(1, 0.08), spacing=10)
        self.remember_check = CheckBox(size_hint=(0.1, 1), color=COLORS['primary'])
        remember_box.add_widget(self.remember_check)
        self.remember_label = Label(
            text=self.lang.get('remember_me'),
            halign='right',
            size_hint=(0.9, 1),
            color=COLORS['text']
        )
        remember_box.add_widget(self.remember_label)
        self.layout.add_widget(remember_box)
        
        # دکمه ورود
        self.login_btn = Button(
            text=self.lang.get('login'),
            size_hint=(1, 0.1),
            background_normal='',
            background_color=COLORS['primary']
        )
        self.login_btn.bind(on_press=self.do_login)
        self.layout.add_widget(self.login_btn)
        
        # دکمه پشتیبانی
        self.support_btn = Button(
            text='📱 ' + self.lang.get('support'),
            size_hint=(1, 0.08),
            background_normal='',
            background_color=COLORS['surface_light'],
            color=COLORS['primary']
        )
        self.support_btn.bind(on_press=self.open_support)
        self.layout.add_widget(self.support_btn)
        
        # زیرنویس پشتیبانی
        self.support_label = Label(
            text=f'پشتیبانی: @Amirho3inGsmad',
            size_hint=(1, 0.05),
            color=COLORS['text_secondary'],
            font_size='12sp'
        )
        self.layout.add_widget(self.support_label)
        
        # وضعیت
        self.status = Label(
            text='',
            size_hint=(1, 0.05),
            color=COLORS['warning']
        )
        self.layout.add_widget(self.status)
        
        self.add_widget(self.layout)
    
    def do_login(self, instance):
        username = self.username.text
        password = self.password.text
        
        if not username or not password:
            self.show_popup('خطا', 'لطفاً نام کاربری و رمز عبور را وارد کنید')
            return
        
        self.status.text = 'در حال بررسی...'
        self.login_btn.disabled = True
        
        Clock.schedule_once(lambda dt: self.check_login_delayed(username, password), 0.5)
    
    def check_login_delayed(self, username, password):
        result = self.db.check_login(username, password, self.device_id)
        
        if result['success']:
            self.status.text = '✅ ورود موفق'
            app = App.get_running_app()
            app.current_user = result['user']
            app.session_token = result['session_token']
            
            if result['user']['is_admin'] == 1:
                self.manager.current = 'admin'
            else:
                self.manager.current = 'user'
        else:
            if result.get('requires_force'):
                self.show_force_login_popup(result['user_id'], username, password)
            else:
                self.status.text = '❌ ' + result['error']
                self.show_popup('خطا', result['error'])
        
        self.login_btn.disabled = False
    
    def show_force_login_popup(self, user_id, username, password):
        content = BoxLayout(orientation='vertical', spacing=10, padding=10)
        content.add_widget(Label(
            text='این کاربر با دستگاه دیگری وارد شده است.\nآیا می‌خواهید نشست قبلی را ببندید و با این دستگاه وارد شوید؟',
            color=COLORS['text']
        ))
        
        btn_box = BoxLayout(size_hint_y=None, height=50, spacing=10)
        
        def force_login(btn):
            self.db.force_end_session(user_id)
            Clock.schedule_once(lambda dt: self.retry_login(username, password), 0.5)
            popup.dismiss()
        
        def cancel(btn):
            popup.dismiss()
        
        force_btn = Button(
            text='بله، وارد شو',
            background_normal='',
            background_color=COLORS['primary']
        )
        force_btn.bind(on_press=force_login)
        
        cancel_btn = Button(
            text='خیر',
            background_normal='',
            background_color=COLORS['danger']
        )
        cancel_btn.bind(on_press=cancel)
        
        btn_box.add_widget(force_btn)
        btn_box.add_widget(cancel_btn)
        
        content.add_widget(btn_box)
        
        popup = Popup(
            title='⚠️ هشدار',
            title_color=COLORS['text'],
            content=content,
            size_hint=(0.8, 0.5)
        )
        popup.open()
    
    def retry_login(self, username, password):
        result = self.db.check_login(username, password, self.device_id)
        
        if result['success']:
            self.status.text = '✅ ورود موفق'
            app = App.get_running_app()
            app.current_user = result['user']
            app.session_token = result['session_token']
            
            if result['user']['is_admin'] == 1:
                self.manager.current = 'admin'
            else:
                self.manager.current = 'user'
    
    def open_support(self, instance):
        import webbrowser
        webbrowser.open(SUPPORT_LINK)
    
    def show_popup(self, title, message):
        popup = Popup(
            title=title,
            title_color=COLORS['text'],
            content=Label(text=message, color=COLORS['text']),
            size_hint=(0.8, 0.4)
        )
        popup.open()
    
    def update_language(self):
        """به‌روزرسانی متن‌ها با زبان جدید"""
        self.username.hint_text = self.lang.get('username')
        self.password.hint_text = self.lang.get('password')
        self.remember_label.text = self.lang.get('remember_me')
        self.login_btn.text = self.lang.get('login')
        self.support_btn.text = '📱 ' + self.lang.get('support')

# ==================== صفحه کاربر عادی ====================

class UserScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.db = DatabaseManager()
        self.v2ray = V2RayCore()
        self.auto_selector = AutoServerSelector(self.db)
        self.lang = App.get_running_app().lang
        self.theme = App.get_running_app().theme
        self.selected_server = None
        self.auto_connect = False
        
        self.layout = BoxLayout(orientation='vertical')
        
        # هدر
        self.header = BoxLayout(size_hint=(1, 0.1), padding=10)
        
        self.menu_btn = Button(
            text='☰',
            size_hint=(0.15, 0.8),
            background_normal='',
            background_color=COLORS['surface_light']
        )
        self.menu_btn.bind(on_press=self.open_menu)
        self.header.add_widget(self.menu_btn)
        
        self.user_label = Label(
            text='',
            size_hint=(0.5, 1),
            halign='center',
            color=COLORS['text']
        )
        self.header.add_widget(self.user_label)
        
        self.conn_status = Button(
            text='🔴 ' + self.lang.get('disconnected'),
            size_hint=(0.35, 0.8),
            background_normal='',
            background_color=COLORS['danger']
        )
        self.conn_status.bind(on_press=self.toggle_connection)
        self.header.add_widget(self.conn_status)
        
        self.layout.add_widget(self.header)
        
        # تبلیغات بنری
        self.banner = BoxLayout(size_hint=(1, 0.1), padding=5)
        self.banner_label = Label(
            text='[📢] تبلیغ: اپلیکیشن اختصاصی VPN - کلیک کن',
            markup=True,
            color=COLORS['warning']
        )
        self.banner.add_widget(self.banner_label)
        self.layout.add_widget(self.banner)
        
        # وضعیت اشتراک
        self.sub_status = BoxLayout(size_hint=(1, 0.2), padding=10, orientation='vertical')
        
        self.info_box = BoxLayout(size_hint_y=None, height=40)
        self.days_label = Label(
            text='⏳ ' + self.lang.get('days_left') + ': --',
            size_hint=(0.5, 1),
            color=COLORS['text']
        )
        self.info_box.add_widget(self.days_label)
        
        self.data_label = Label(
            text='📊 ' + self.lang.get('data_used') + ': 0 MB',
            size_hint=(0.5, 1),
            color=COLORS['text']
        )
        self.info_box.add_widget(self.data_label)
        self.sub_status.add_widget(self.info_box)
        
        self.progress_bar = BoxLayout(
            size_hint=(1, 0.3),
            padding=2
        )
        with self.progress_bar.canvas.before:
            Color(0.2, 0.2, 0.3, 1)
            self.progress_bg = Rectangle(size=self.progress_bar.size, pos=self.progress_bar.pos)
        
        self.progress_fill = BoxLayout(size_hint_x=0.8)
        with self.progress_fill.canvas.before:
            Color(*[int(COLORS['primary'].lstrip('#')[i:i+2], 16)/255 for i in (0, 2, 4)])
            self.progress_fill_rect = Rectangle(size=self.progress_fill.size, pos=self.progress_fill.pos)
        
        self.progress_bar.add_widget(self.progress_fill)
        self.sub_status.add_widget(self.progress_bar)
        
        # دکمه خودکار
        auto_box = BoxLayout(size_hint_y=None, height=40, spacing=10)
        self.auto_check = CheckBox(size_hint=(0.1, 1), color=COLORS['primary'])
        self.auto_check.bind(active=self.on_auto_toggle)
        auto_box.add_widget(self.auto_check)
        
        self.auto_label = Label(
            text=self.lang.get('auto_connect'),
            halign='right',
            size_hint=(0.6, 1),
            color=COLORS['text']
        )
        auto_box.add_widget(self.auto_label)
        
        self.best_server_btn = Button(
            text='⚡ ' + self.lang.get('best_server'),
            size_hint=(0.3, 1),
            background_normal='',
            background_color=COLORS['success']
        )
        self.best_server_btn.bind(on_press=self.connect_best_server)
        auto_box.add_widget(self.best_server_btn)
        
        self.sub_status.add_widget(auto_box)
        
        self.layout.add_widget(self.sub_status)
        
        # لیست سرورها
        self.scroll = ScrollView(size_hint=(1, 0.6))
        self.servers_grid = GridLayout(cols=1, spacing=10, size_hint_y=None, padding=10)
        self.servers_grid.bind(minimum_height=self.servers_grid.setter('height'))
        self.scroll.add_widget(self.servers_grid)
        self.layout.add_widget(self.scroll)
        
        self.add_widget(self.layout)
    
    def on_enter(self):
        app = App.get_running_app()
        if hasattr(app, 'current_user'):
            user = app.current_user
            self.user_label.text = f'👤 {user["fullname"]}'
            self.load_servers()
            self.update_status()
        
        Clock.schedule_interval(self.update_status, 5)
        Clock.schedule_interval(self.update_connection_status, 2)
    
    def load_servers(self):
        self.servers_grid.clear_widgets()
        servers = self.db.get_all_servers()
        
        for server in servers:
            if not server['is_active']:
                continue
            
            card = BoxLayout(
                orientation='vertical',
                size_hint_y=None,
                height=160,
                padding=10,
                spacing=5
            )
            
            with card.canvas.before:
                Color(*[int(COLORS['surface'].lstrip('#')[i:i+2], 16)/255 for i in (0, 2, 4)])
                RoundedRectangle(size=card.size, pos=card.pos, radius=[10])
            
            header = BoxLayout(size_hint_y=None, height=40)
            flag = Label(text=server['flag'], font_size='24sp', size_hint=(0.15, 1))
            header.add_widget(flag)
            
            name = Label(
                text=f'[b]{server["name"]}[/b]',
                markup=True,
                size_hint=(0.6, 1),
                halign='right',
                color=COLORS['text']
            )
            header.add_widget(name)
            
            ping = Label(
                text=f'{server["ping"]}ms',
                size_hint=(0.25, 1),
                color=COLORS['success'] if server['ping'] < 150 else COLORS['warning']
            )
            header.add_widget(ping)
            card.add_widget(header)
            
            info = Label(
                text=f'📍 {server["location"]} | 📡 {server["protocol"]}',
                size_hint_y=None,
                height=30,
                color=COLORS['text_secondary']
            )
            card.add_widget(info)
            
            connect_btn = Button(
                text='🔌 ' + self.lang.get('login'),
                size_hint_y=None,
                height=50,
                background_normal='',
                background_color=COLORS['surface_light']
            )
            connect_btn.server_id = server['id']
            connect_btn.server_name = server['name']
            connect_btn.bind(on_press=self.select_server)
            
            if self.selected_server == server['id']:
                connect_btn.background_color = COLORS['primary']
                connect_btn.text = '✅ ' + self.lang.get('connected')
            
            card.add_widget(connect_btn)
            
            self.servers_grid.add_widget(card)
    
    def on_auto_toggle(self, instance, value):
        self.auto_connect = value
    
    def connect_best_server(self, instance):
        best = self.auto_selector.find_best_server()
        if best:
            self.selected_server = best['id']
            self.load_servers()
            self.connect_to_server_by_id(best['id'])
    
    def select_server(self, instance):
        self.selected_server = instance.server_id
        self.load_servers()
        self.connect_to_server_by_id(instance.server_id)
    
    def connect_to_server_by_id(self, server_id):
        app = App.get_running_app()
        
        if not self.db.check_subscription(app.current_user['id']):
            self.show_popup('⚠️ خطا', 'اشتراک شما به پایان رسیده است')
            return
        
        config = self.db.get_server_config(server_id)
        if not config or (not config['vmess'] and not config['vless']):
            self.show_popup('❌ خطا', 'کانفیگ سرور یافت نشد')
            return
        
        self.show_connecting_popup()
        
        def do_connect():
            result = self.v2ray.connect(
                server_id,
                "سرور",
                vmess_link=config['vmess'],
                vless_link=config['vless'],
                protocol=config['protocol']
            )
            Clock.schedule_once(lambda dt: self.connection_result(result))
        
        threading.Thread(target=do_connect).start()
    
    def show_connecting_popup(self):
        content = BoxLayout(orientation='vertical', spacing=10)
        content.add_widget(Label(text='در حال اتصال...', color=COLORS['text']))
        content.add_widget(Label(text='⏳', font_size='48sp'))
        
        self.conn_popup = Popup(
            title='🔄 اتصال',
            title_color=COLORS['text'],
            content=content,
            size_hint=(0.6, 0.4),
            auto_dismiss=False
        )
        self.conn_popup.open()
    
    def connection_result(self, result):
        self.conn_popup.dismiss()
        
        if result['success']:
            self.conn_status.text = '🟢 ' + self.lang.get('connected')
            self.conn_status.background_color = COLORS['success']
            self.show_popup('✅ موفق', result['message'])
        else:
            self.show_popup('❌ خطا', result.get('error', 'خطا در اتصال'))
    
    def toggle_connection(self, instance):
        if self.v2ray.connected:
            result = self.v2ray.disconnect()
            if result['success']:
                self.conn_status.text = '🔴 ' + self.lang.get('disconnected')
                self.conn_status.background_color = COLORS['danger']
                self.show_popup('✅ قطع', 'اتصال قطع شد')
    
    def update_status(self, dt=None):
        app = App.get_running_app()
        if hasattr(app, 'current_user'):
            days, hours = self.db.get_user_days_left(app.current_user['id'])
            usage = self.db.usage_manager.get_user_usage(app.current_user['id'])
            
            if days > 30:
                self.days_label.text = f'⏳ {self.lang.get("days_left")}: {days}'
                self.days_label.color = COLORS['text']
            elif days > 7:
                self.days_label.text = f'⏳ {self.lang.get("days_left")}: {days} ({hours}h)'
                self.days_label.color = COLORS['text']
            elif days > 0:
                self.days_label.text = f'⚠️ {self.lang.get("days_left")}: {days} ({hours}h)'
                self.days_label.color = COLORS['warning']
            else:
                self.days_label.text = f'❌ {self.lang.get("days_left")}: 0'
                self.days_label.color = COLORS['danger']
            
            # نمایش مصرف
            data_mb = usage['total'] / (1024 * 1024)
            limit_mb = app.current_user.get('data_limit', 0)
            if limit_mb > 0:
                self.data_label.text = f'📊 {self.lang.get("data_used")}: {data_mb:.1f}MB / {limit_mb}MB'
                progress = min(1.0, data_mb / limit_mb)
                self.progress_fill.size_hint_x = progress
            else:
                self.data_label.text = f'📊 {self.lang.get("data_used")}: {data_mb:.1f}MB'
    
    def update_connection_status(self, dt):
        status = self.v2ray.get_status()
        if status['connected']:
            self.conn_status.text = '🟢 ' + self.lang.get('connected')
            self.conn_status.background_color = COLORS['success']
        else:
            self.conn_status.text = '🔴 ' + self.lang.get('disconnected')
            self.conn_status.background_color = COLORS['danger']
    
    def open_menu(self, instance):
        """باز کردن منوی تنظیمات"""
        content = BoxLayout(orientation='vertical', spacing=10, padding=10)
        
        # تغییر زبان
        lang_box = BoxLayout(size_hint_y=None, height=50)
        lang_box.add_widget(Label(
            text=self.lang.get('language') + ':',
            size_hint=(0.5, 1),
            color=COLORS['text']
        ))
        
        lang_btn = Button(
            text='فارسی' if self.lang.current_lang == 'en' else 'English',
            size_hint=(0.5, 1),
            background_normal='',
            background_color=COLORS['surface_light']
        )
        lang_btn.bind(on_press=self.toggle_language)
        lang_box.add_widget(lang_btn)
        content.add_widget(lang_box)
        
        # تغییر تم
        theme_box = BoxLayout(size_hint_y=None, height=50)
        theme_box.add_widget(Label(
            text=self.lang.get('dark_mode') + ':',
            size_hint=(0.5, 1),
            color=COLORS['text']
        ))
        
        theme_switch = Switch(active=self.theme.is_dark)
        theme_switch.bind(active=self.toggle_theme)
        theme_box.add_widget(theme_switch)
        content.add_widget(theme_box)
        
        # دکمه خروج
        logout_btn = Button(
            text=self.lang.get('logout'),
            size_hint_y=None,
            height=50,
            background_normal='',
            background_color=COLORS['danger']
        )
        logout_btn.bind(on_press=self.do_logout)
        content.add_widget(logout_btn)
        
        popup = Popup(
            title=self.lang.get('settings'),
            title_color=COLORS['text'],
            content=content,
            size_hint=(0.8, 0.5)
        )
        popup.open()
    
    def toggle_language(self, instance):
        app = App.get_running_app()
        app.lang.toggle_language()
        
        # به‌روزرسانی همه صفحه‌ها
        self.manager.get_screen('login').update_language()
        self.update_ui_language()
    
    def toggle_theme(self, instance, value):
        app = App.get_running_app()
        app.theme.toggle_theme()
        self.update_ui_theme()
    
    def update_ui_language(self):
        """به‌روزرسانی متن‌های این صفحه"""
        self.conn_status.text = ('🟢 ' if self.v2ray.connected else '🔴 ') + self.lang.get('connected' if self.v2ray.connected else 'disconnected')
        self.auto_label.text = self.lang.get('auto_connect')
        self.best_server_btn.text = '⚡ ' + self.lang.get('best_server')
        self.load_servers()
    
    def update_ui_theme(self):
        """به‌روزرسانی تم این صفحه"""
        pass
    
    def do_logout(self, instance):
        self.v2ray.disconnect()
        self.manager.current = 'login'
    
    def show_popup(self, title, message):
        popup = Popup(
            title=title,
            title_color=COLORS['text'],
            content=Label(text=message, color=COLORS['text']),
            size_hint=(0.8, 0.4)
        )
        popup.open()

# ==================== صفحه ادمین ====================

class AdminScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.db = DatabaseManager()
        self.lang = App.get_running_app().lang
        self.theme = App.get_running_app().theme
        self.telegram_backup = App.get_running_app().telegram_backup
        
        self.layout = BoxLayout(orientation='vertical')
        
        # هدر
        self.header = BoxLayout(size_hint=(1, 0.1), padding=10)
        
        self.title = Label(
            text='[b]👑 پنل مدیریت[/b]',
            markup=True,
            size_hint=(0.8, 1),
            font_size='18sp',
            color=COLORS['primary']
        )
        self.header.add_widget(self.title)
        
        self.logout_btn = Button(
            text='🚪',
            size_hint=(0.15, 0.8),
            background_normal='',
            background_color=COLORS['surface_light']
        )
        self.logout_btn.bind(on_press=self.do_logout)
        self.header.add_widget(self.logout_btn)
        self.layout.add_widget(self.header)
        
        # تب‌ها
        self.tabs = TabbedPanel(
            do_default_tab=False,
            background_color=COLORS['background']
        )
        
        # تب کاربران
        tab_users = TabbedPanelHeader(text='👥 کاربران')
        tab_users.content = self.create_users_tab()
        self.tabs.add_widget(tab_users)
        
        # تب سرورها
        tab_servers = TabbedPanelHeader(text='🌍 سرورها')
        tab_servers.content = self.create_servers_tab()
        self.tabs.add_widget(tab_servers)
        
        # تب تبلیغات
        tab_ads = TabbedPanelHeader(text='📢 تبلیغات')
        tab_ads.content = self.create_ads_tab()
        self.tabs.add_widget(tab_ads)
        
        # تب آمار
        tab_stats = TabbedPanelHeader(text='📊 آمار')
        tab_stats.content = self.create_stats_tab()
        self.tabs.add_widget(tab_stats)
        
        # تب بکاپ (با دکمه ارسال دستی)
        tab_backup = TabbedPanelHeader(text='💾 بکاپ')
        tab_backup.content = self.create_backup_tab()
        self.tabs.add_widget(tab_backup)
        
        self.layout.add_widget(self.tabs)
        self.add_widget(self.layout)
    
    # ========== تب کاربران ==========
    
    def create_users_tab(self):
        layout = BoxLayout(orientation='vertical', padding=10)
        
        # فرم افزودن کاربر
        form = BoxLayout(orientation='vertical', size_hint_y=None, height=250, spacing=5)
        form.add_widget(Label(
            text='➕ افزودن کاربر جدید',
            size_hint_y=None,
            height=30,
            color=COLORS['primary']
        ))
        
        self.new_username = TextInput(
            hint_text='نام کاربری',
            multiline=False,
            background_color=COLORS['surface'],
            foreground_color=COLORS['text']
        )
        form.add_widget(self.new_username)
        
        self.new_password = TextInput(
            hint_text='رمز عبور',
            password=True,
            multiline=False,
            background_color=COLORS['surface'],
            foreground_color=COLORS['text']
        )
        form.add_widget(self.new_password)
        
        self.new_fullname = TextInput(
            hint_text='نام و نام خانوادگی',
            multiline=False,
            background_color=COLORS['surface'],
            foreground_color=COLORS['text']
        )
        form.add_widget(self.new_fullname)
        
        sub_box = BoxLayout(size_hint_y=None, height=40)
        sub_box.add_widget(Label(text='نوع اشتراک:', size_hint=(0.3, 1), color=COLORS['text']))
        self.sub_spinner = Spinner(
            text='ماهانه',
            values=['ماهانه', 'سه ماهه', 'شش ماهه', 'یکساله'],
            size_hint=(0.7, 1),
            background_color=COLORS['surface']
        )
        sub_box.add_widget(self.sub_spinner)
        form.add_widget(sub_box)
        
        admin_box = BoxLayout(size_hint_y=None, height=40)
        admin_box.add_widget(Label(text='دسترسی:', size_hint=(0.3, 1), color=COLORS['text']))
        self.admin_spinner = Spinner(
            text='کاربر عادی',
            values=['کاربر عادی', 'ادمین'],
            size_hint=(0.7, 1),
            background_color=COLORS['surface']
        )
        admin_box.add_widget(self.admin_spinner)
        form.add_widget(admin_box)
        
        btn_add = Button(
            text='✅ افزودن کاربر',
            size_hint_y=None,
            height=50,
            background_normal='',
            background_color=COLORS['primary']
        )
        btn_add.bind(on_press=self.add_user)
        form.add_widget(btn_add)
        
        layout.add_widget(form)
        
        # لیست کاربران
        layout.add_widget(Label(
            text='📋 لیست کاربران',
            size_hint_y=None,
            height=30,
            color=COLORS['text']
        ))
        
        scroll = ScrollView()
        self.users_grid = GridLayout(cols=1, spacing=5, size_hint_y=None)
        self.users_grid.bind(minimum_height=self.users_grid.setter('height'))
        
        self.load_users()
        
        scroll.add_widget(self.users_grid)
        layout.add_widget(scroll)
        
        return layout
    
    def load_users(self):
        self.users_grid.clear_widgets()
        users = self.db.get_all_users()
        
        for user in users:
            if user['username'] == ADMIN_USERNAME:
                continue
            
            card = BoxLayout(
                orientation='vertical',
                size_hint_y=None,
                height=140,
                padding=5,
                spacing=2
            )
            
            with card.canvas.before:
                Color(*[int(COLORS['surface'].lstrip('#')[i:i+2], 16)/255 for i in (0, 2, 4)])
                RoundedRectangle(size=card.size, pos=card.pos, radius=[5])
            
            info = f"👤 {user['username']} - {user['fullname'] or '---'}"
            status = "✅ فعال" if user['is_active'] else "❌ غیرفعال"
            sub_type = {
                'monthly': 'ماهانه',
                'quarterly': 'سه ماهه',
                'biannual': 'شش ماهه',
                'yearly': 'یکساله'
            }.get(user['subscription_type'], '---')
            
            card.add_widget(Label(
                text=f"{info} | {sub_type} | {status}",
                halign='right',
                color=COLORS['text']
            ))
            
            if user['subscription_end']:
                end_date = datetime.strptime(user['subscription_end'], '%Y-%m-%d %H:%M:%S')
                days = (end_date - datetime.now()).days
                card.add_widget(Label(
                    text=f"⏳ پایان: {end_date.strftime('%Y/%m/%d')} ({days} روز)",
                    halign='right',
                    color=COLORS['text_secondary']
                ))
            
            # نمایش دستگاه فعال
            if user['last_device']:
                device_label = Label(
                    text=f"📱 دستگاه: {user['last_device'][:8]}...",
                    halign='right',
                    color=COLORS['text_secondary']
                )
                card.add_widget(device_label)
            
            btn_box = BoxLayout(size_hint_y=None, height=40, spacing=5)
            
            edit_btn = Button(
                text='✏️ ویرایش',
                size_hint=(0.2, 1),
                background_normal='',
                background_color=COLORS['primary']
            )
            edit_btn.user = user
            edit_btn.bind(on_press=self.edit_user)
            btn_box.add_widget(edit_btn)
            
            renew_btn = Button(
                text='🔄 تمدید',
                size_hint=(0.2, 1),
                background_normal='',
                background_color=COLORS['warning']
            )
            renew_btn.user_id = user['id']
            renew_btn.bind(on_press=self.renew_user)
            btn_box.add_widget(renew_btn)
            
            toggle_btn = Button(
                text='🔘 وضعیت',
                size_hint=(0.2, 1),
                background_normal='',
                background_color=COLORS['surface_light']
            )
            toggle_btn.user_id = user['id']
            toggle_btn.bind(on_press=self.toggle_user)
            btn_box.add_widget(toggle_btn)
            
            close_btn = Button(
                text='🔒 بستن نشست',
                size_hint=(0.2, 1),
                background_normal='',
                background_color=COLORS['danger']
            )
            close_btn.user_id = user['id']
            close_btn.bind(on_press=self.close_session)
            btn_box.add_widget(close_btn)
            
            delete_btn = Button(
                text='🗑 حذف',
                size_hint=(0.2, 1),
                background_normal='',
                background_color=COLORS['danger']
            )
            delete_btn.user_id = user['id']
            delete_btn.bind(on_press=self.delete_user)
            btn_box.add_widget(delete_btn)
            
            card.add_widget(btn_box)
            self.users_grid.add_widget(card)
    
    def add_user(self, instance):
        username = self.new_username.text
        password = self.new_password.text
        
        if not username or not password:
            self.show_popup('خطا', 'نام کاربری و رمز عبور الزامی است')
            return
        
        sub_map = {
            'ماهانه': 'monthly',
            'سه ماهه': 'quarterly',
            'شش ماهه': 'biannual',
            'یکساله': 'yearly'
        }
        subscription_type = sub_map.get(self.sub_spinner.text, 'monthly')
        is_admin = 1 if self.admin_spinner.text == 'ادمین' else 0
        
        user_id = self.db.create_user(
            username=username,
            password=password,
            fullname=self.new_fullname.text,
            is_admin=is_admin,
            subscription_type=subscription_type
        )
        
        if user_id:
            self.show_popup('✅ موفق', 'کاربر با موفقیت ساخته شد')
            self.new_username.text = ''
            self.new_password.text = ''
            self.new_fullname.text = ''
            self.load_users()
        else:
            self.show_popup('❌ خطا', 'این نام کاربری قبلاً وجود دارد')
    
    def edit_user(self, instance):
        user = instance.user
        
        content = BoxLayout(orientation='vertical', spacing=10, padding=10)
        content.add_widget(Label(text=f'ویرایش کاربر {user["username"]}', color=COLORS['text']))
        
        content.add_widget(Label(text='نام کاربری جدید:', color=COLORS['text']))
        new_username = TextInput(
            text=user['username'],
            multiline=False,
            background_color=COLORS['surface'],
            foreground_color=COLORS['text']
        )
        content.add_widget(new_username)
        
        content.add_widget(Label(text='رمز عبور جدید (خالی = بدون تغییر):', color=COLORS['text']))
        new_password = TextInput(
            password=True,
            multiline=False,
            background_color=COLORS['surface'],
            foreground_color=COLORS['text']
        )
        content.add_widget(new_password)
        
        btn_box = BoxLayout(size_hint_y=None, height=50, spacing=10)
        
        def save_changes(btn):
            data = {}
            if new_username.text and new_username.text != user['username']:
                data['username'] = new_username.text
            if new_password.text:
                data['password'] = new_password.text
            
            if data:
                self.db.update_user(user['id'], data)
                self.show_popup('✅ موفق', 'اطلاعات کاربر بروزرسانی شد')
                self.load_users()
            
            popup.dismiss()
        
        save_btn = Button(
            text='ذخیره',
            background_normal='',
            background_color=COLORS['primary']
        )
        save_btn.bind(on_press=save_changes)
        
        cancel_btn = Button(
            text='لغو',
            background_normal='',
            background_color=COLORS['danger']
        )
        cancel_btn.bind(on_press=lambda x: popup.dismiss())
        
        btn_box.add_widget(save_btn)
        btn_box.add_widget(cancel_btn)
        content.add_widget(btn_box)
        
        popup = Popup(
            title='✏️ ویرایش کاربر',
            title_color=COLORS['text'],
            content=content,
            size_hint=(0.8, 0.6)
        )
        popup.open()
    
    def renew_user(self, instance):
        self.db.update_user_subscription(instance.user_id, 'monthly', 30)
        self.show_popup('✅ موفق', 'اشتراک کاربر تمدید شد')
        self.load_users()
    
    def toggle_user(self, instance):
        self.db.toggle_user_status(instance.user_id)
        self.load_users()
    
    def close_session(self, instance):
        self.db.force_end_session(instance.user_id)
        self.show_popup('✅ موفق', 'نشست کاربر بسته شد')
        self.load_users()
    
    def delete_user(self, instance):
        content = BoxLayout(orientation='vertical')
        content.add_widget(Label(text='آیا از حذف این کاربر اطمینان دارید؟', color=COLORS['text']))
        
        btn_box = BoxLayout(size_hint_y=None, height=40)
        
        def confirm(btn):
            self.db.delete_user(instance.user_id)
            popup.dismiss()
            self.load_users()
        
        def cancel(btn):
            popup.dismiss()
        
        confirm_btn = Button(
            text='بله',
            background_normal='',
            background_color=COLORS['danger']
        )
        confirm_btn.bind(on_press=confirm)
        btn_box.add_widget(confirm_btn)
        
        cancel_btn = Button(
            text='خیر',
            background_normal='',
            background_color=COLORS['surface_light']
        )
        cancel_btn.bind(on_press=cancel)
        btn_box.add_widget(cancel_btn)
        
        content.add_widget(btn_box)
        
        popup = Popup(
            title='تأیید حذف',
            title_color=COLORS['text'],
            content=content,
            size_hint=(0.8, 0.4)
        )
        popup.open()
    
    # ========== تب سرورها ==========
    
    def create_servers_tab(self):
        layout = BoxLayout(orientation='vertical', padding=10)
        
        # فرم افزودن سرور
        form = BoxLayout(orientation='vertical', size_hint_y=None, height=350, spacing=5)
        form.add_widget(Label(
            text='➕ افزودن سرور جدید',
            size_hint_y=None,
            height=30,
            color=COLORS['primary']
        ))
        
        self.server_name = TextInput(
            hint_text='نام سرور (مثلاً آلمان)',
            multiline=False,
            background_color=COLORS['surface'],
            foreground_color=COLORS['text']
        )
        form.add_widget(self.server_name)
        
        self.server_ip = TextInput(
            hint_text='آدرس IP',
            multiline=False,
            background_color=COLORS['surface'],
            foreground_color=COLORS['text']
        )
        form.add_widget(self.server_ip)
        
        self.server_location = TextInput(
            hint_text='موقعیت (مثلاً فرانکفورت)',
            multiline=False,
            background_color=COLORS['surface'],
            foreground_color=COLORS['text']
        )
        form.add_widget(self.server_location)
        
        row1 = BoxLayout(size_hint_y=None, height=40)
        self.server_flag = TextInput(
            hint_text='پرچم',
            text='🇩🇪',
            size_hint=(0.3, 1),
            background_color=COLORS['surface'],
            foreground_color=COLORS['text']
        )
        row1.add_widget(self.server_flag)
        
        self.server_protocol = Spinner(
            text='vmess',
            values=['vmess', 'vless'],
            size_hint=(0.3, 1),
            background_color=COLORS['surface']
        )
        row1.add_widget(self.server_protocol)
        
        self.server_port = TextInput(
            hint_text='پورت',
            text='443',
            size_hint=(0.3, 1),
            background_color=COLORS['surface'],
            foreground_color=COLORS['text']
        )
        row1.add_widget(self.server_port)
        form.add_widget(row1)
        
        form.add_widget(Label(
            text='🔗 لینک VMess (مخفی - اختیاری):',
            size_hint_y=None,
            height=30,
            color=COLORS['text']
        ))
        
        self.server_vmess = TextInput(
            hint_text='vmess://...',
            multiline=True,
            size_hint_y=None,
            height=60,
            background_color=COLORS['surface'],
            foreground_color=COLORS['text']
        )
        form.add_widget(self.server_vmess)
        
        form.add_widget(Label(
            text='🔗 لینک VLESS (مخفی - اختیاری):',
            size_hint_y=None,
            height=30,
            color=COLORS['text']
        ))
        
        self.server_vless = TextInput(
            hint_text='vless://...',
            multiline=True,
            size_hint_y=None,
            height=60,
            background_color=COLORS['surface'],
            foreground_color=COLORS['text']
        )
        form.add_widget(self.server_vless)
        
        btn_add = Button(
            text='✅ افزودن سرور',
            size_hint_y=None,
            height=50,
            background_normal='',
            background_color=COLORS['primary']
        )
        btn_add.bind(on_press=self.add_server)
        form.add_widget(btn_add)
        
        layout.add_widget(form)
        
        # لیست سرورها
        layout.add_widget(Label(
            text='📋 لیست سرورها',
            size_hint_y=None,
            height=30,
            color=COLORS['text']
        ))
        
        scroll = ScrollView()
        self.servers_grid = GridLayout(cols=1, spacing=5, size_hint_y=None)
        self.servers_grid.bind(minimum_height=self.servers_grid.setter('height'))
        
        self.load_servers_list()
        
        scroll.add_widget(self.servers_grid)
        layout.add_widget(scroll)
        
        return layout
    
    def load_servers_list(self):
        self.servers_grid.clear_widgets()
        servers = self.db.get_all_servers()
        
        for server in servers:
            card = BoxLayout(
                orientation='vertical',
                size_hint_y=None,
                height=100,
                padding=5
            )
            
            with card.canvas.before:
                Color(*[int(COLORS['surface'].lstrip('#')[i:i+2], 16)/255 for i in (0, 2, 4)])
                RoundedRectangle(size=card.size, pos=card.pos, radius=[5])
            
            status = "✅ فعال" if server['is_active'] else "❌ غیرفعال"
            info = f"{server['flag']} {server['name']} - {server['location']} | {status}"
            card.add_widget(Label(text=info, halign='right', color=COLORS['text']))
            
            config_info = ""
            if server['has_vmess']:
                config_info += "🔵 VMess "
            if server['has_vless']:
                config_info += "🟣 VLESS"
            if config_info:
                card.add_widget(Label(text=config_info, halign='right', color=COLORS['text_secondary'], font_size='12sp'))
            
            btn_box = BoxLayout(size_hint_y=None, height=40, spacing=5)
            
            toggle_btn = Button(
                text='🔄 فعال/غیرفعال',
                size_hint=(0.5, 1),
                background_normal='',
                background_color=COLORS['surface_light']
            )
            toggle_btn.server_id = server['id']
            toggle_btn.bind(on_press=self.toggle_server)
            btn_box.add_widget(toggle_btn)
            
            delete_btn = Button(
                text='🗑 حذف',
                size_hint=(0.5, 1),
                background_normal='',
                background_color=COLORS['danger']
            )
            delete_btn.server_id = server['id']
            delete_btn.bind(on_press=self.delete_server)
            btn_box.add_widget(delete_btn)
            
            card.add_widget(btn_box)
            self.servers_grid.add_widget(card)
    
    def add_server(self, instance):
        name = self.server_name.text
        ip = self.server_ip.text
        location = self.server_location.text
        flag = self.server_flag.text
        protocol = self.server_protocol.text
        try:
            port = int(self.server_port.text)
        except:
            port = 443
        vmess = self.server_vmess.text
        vless = self.server_vless.text
        
        if not name or not ip or (not vmess and not vless):
            self.show_popup('خطا', 'نام، آدرس IP و حداقل یک لینک (VMess یا VLESS) الزامی است')
            return
        
        self.db.add_server(
            name=name,
            ip_address=ip,
            location=location,
            flag_icon=flag,
            protocol=protocol,
            port=port,
            vmess_link=vmess,
            vless_link=vless
        )
        
        self.show_popup('✅ موفق', 'سرور با موفقیت اضافه شد')
        
        self.server_name.text = ''
        self.server_ip.text = ''
        self.server_location.text = ''
        self.server_flag.text = '🇩🇪'
        self.server_vmess.text = ''
        self.server_vless.text = ''
        
        self.load_servers_list()
    
    def toggle_server(self, instance):
        self.db.toggle_server_status(instance.server_id)
        self.load_servers_list()
    
    def delete_server(self, instance):
        self.db.delete_server(instance.server_id)
        self.load_servers_list()
    
    # ========== تب تبلیغات ==========
    
    def create_ads_tab(self):
        layout = BoxLayout(orientation='vertical', padding=10)
        
        # فرم افزودن تبلیغ
        form = BoxLayout(orientation='vertical', size_hint_y=None, height=200, spacing=5)
        form.add_widget(Label(
            text='➕ افزودن تبلیغ جدید',
            size_hint_y=None,
            height=30,
            color=COLORS['primary']
        ))
        
        self.ad_title = TextInput(
            hint_text='عنوان تبلیغ',
            multiline=False,
            background_color=COLORS['surface'],
            foreground_color=COLORS['text']
        )
        form.add_widget(self.ad_title)
        
        self.ad_image = TextInput(
            hint_text='آدرس تصویر',
            multiline=False,
            text='assets/ads/banner.png',
            background_color=COLORS['surface'],
            foreground_color=COLORS['text']
        )
        form.add_widget(self.ad_image)
        
        self.ad_link = TextInput(
            hint_text='لینک مقصد',
            multiline=False,
            text=SUPPORT_LINK,
            background_color=COLORS['surface'],
            foreground_color=COLORS['text']
        )
        form.add_widget(self.ad_link)
        
        btn_add = Button(
            text='➕ افزودن تبلیغ',
            size_hint_y=None,
            height=40,
            background_normal='',
            background_color=COLORS['primary']
        )
        btn_add.bind(on_press=self.add_ad)
        form.add_widget(btn_add)
        
        layout.add_widget(form)
        
        # لیست تبلیغات
        layout.add_widget(Label(
            text='📋 تبلیغات فعال',
            size_hint_y=None,
            height=30,
            color=COLORS['text']
        ))
        
        scroll = ScrollView()
        self.ads_grid = GridLayout(cols=1, spacing=5, size_hint_y=None)
        self.ads_grid.bind(minimum_height=self.ads_grid.setter('height'))
        
        self.load_ads_list()
        
        scroll.add_widget(self.ads_grid)
        layout.add_widget(scroll)
        
        return layout
    
    def load_ads_list(self):
        self.ads_grid.clear_widgets()
        ads = self.db.get_all_ads()
        
        for ad in ads:
            card = BoxLayout(
                orientation='vertical',
                size_hint_y=None,
                height=80,
                padding=5
            )
            
            with card.canvas.before:
                Color(*[int(COLORS['surface'].lstrip('#')[i:i+2], 16)/255 for i in (0, 2, 4)])
                RoundedRectangle(size=card.size, pos=card.pos, radius=[5])
            
            info = f"{ad['title']} | بازدید: {ad['views']} | کلیک: {ad['clicks']}"
            card.add_widget(Label(text=info, halign='right', color=COLORS['text']))
            
            btn_box = BoxLayout(size_hint_y=None, height=40, spacing=5)
            
            toggle_btn = Button(
                text='🔄 غیرفعال',
                size_hint=(0.5, 1),
                background_normal='',
                background_color=COLORS['surface_light']
            )
            btn_box.add_widget(toggle_btn)
            
            delete_btn = Button(
                text='🗑 حذف',
                size_hint=(0.5, 1),
                background_normal='',
                background_color=COLORS['danger']
            )
            btn_box.add_widget(delete_btn)
            
            card.add_widget(btn_box)
            self.ads_grid.add_widget(card)
    
    def add_ad(self, instance):
        title = self.ad_title.text
        image = self.ad_image.text
        link = self.ad_link.text
        
        if title and image and link:
            self.db.add_ad(title, image, link)
            self.ad_title.text = ''
            self.ad_image.text = 'assets/ads/banner.png'
            self.ad_link.text = SUPPORT_LINK
            self.show_popup('✅ موفق', 'تبلیغ با موفقیت اضافه شد')
            self.load_ads_list()
    
    # ========== تب آمار ==========
    
    def create_stats_tab(self):
        layout = BoxLayout(orientation='vertical', padding=20, spacing=20)
        
        stats = self.db.get_stats()
        
        grid = GridLayout(cols=2, spacing=15, size_hint_y=None, height=400)
        
        cards = [
            ('👥 کل کاربران', stats['total_users'], COLORS['primary']),
            ('✅ کاربران فعال', stats['active_users'], COLORS['success']),
            ('🌍 سرورهای فعال', stats['active_servers'], COLORS['warning']),
            ('👑 مدیران', stats['admins'], COLORS['secondary']),
            ('📱 نشست‌های فعال', stats['active_sessions'], COLORS['primary']),
            ('📢 تعداد تبلیغات', stats['ads'], COLORS['warning']),
            ('💾 تعداد بکاپ', stats['backups'], COLORS['success'])
        ]
        
        for title, value, color in cards:
            card = BoxLayout(orientation='vertical', padding=15)
            with card.canvas.before:
                Color(*[int(color.lstrip('#')[i:i+2], 16)/255 for i in (0, 2, 4)])
                RoundedRectangle(size=card.size, pos=card.pos, radius=[10])
            
            card.add_widget(Label(
                text=title,
                font_size='14sp',
                color=COLORS['text'],
                halign='center'
            ))
            card.add_widget(Label(
                text=str(value),
                font_size='32sp',
                bold=True,
                color=COLORS['text'],
                halign='center'
            ))
            grid.add_widget(card)
        
        layout.add_widget(grid)
        
        info = BoxLayout(orientation='vertical', size_hint_y=None, height=150)
        info.add_widget(Label(
            text='📱 اطلاعات برنامه',
            font_size='16sp',
            color=COLORS['primary']
        ))
        info.add_widget(Label(text=f'نام: {APP_NAME}', color=COLORS['text']))
        info.add_widget(Label(text=f'نسخه: {APP_VERSION}', color=COLORS['text']))
        info.add_widget(Label(text=f'پشتیبانی: @Amirho3inGsmad', color=COLORS['text']))
        info.add_widget(Label(text=f'✅ بکاپ خودکار: هر ۱۲ ساعت به تلگرام', color=COLORS['success']))
        
        layout.add_widget(info)
        
        return layout
    
    # ========== تب بکاپ ==========
    
    def create_backup_tab(self):
        layout = BoxLayout(orientation='vertical', padding=20, spacing=15)
        
        # عنوان
        title = Label(
            text='[b]💾 مدیریت بکاپ[/b]',
            markup=True,
            size_hint_y=None,
            height=50,
            font_size='18sp',
            color=COLORS['primary']
        )
        layout.add_widget(title)
        
        # دکمه‌ها
        btn_box = BoxLayout(size_hint_y=None, height=50, spacing=10)
        
        backup_btn = Button(
            text='📤 ایجاد بکاپ دستی',
            background_normal='',
            background_color=COLORS['primary']
        )
        backup_btn.bind(on_press=self.manual_backup)
        btn_box.add_widget(backup_btn)
        
        refresh_btn = Button(
            text='🔄 بروزرسانی لیست',
            background_normal='',
            background_color=COLORS['surface_light']
        )
        refresh_btn.bind(on_press=self.refresh_backup_list)
        btn_box.add_widget(refresh_btn)
        
        layout.add_widget(btn_box)
        
        # وضعیت بکاپ خودکار
        status_box = BoxLayout(size_hint_y=None, height=40)
        status_box.add_widget(Label(
            text='🤖 بکاپ خودکار:',
            size_hint=(0.5, 1),
            color=COLORS['text']
        ))
        status_box.add_widget(Label(
            text='✅ فعال (هر ۱۲ ساعت)',
            size_hint=(0.5, 1),
            color=COLORS['success']
        ))
        layout.add_widget(status_box)
        
        # آخرین بکاپ
        self.last_backup_label = Label(
            text='⏳ آخرین بکاپ: ---',
            size_hint_y=None,
            height=30,
            color=COLORS['text_secondary']
        )
        layout.add_widget(self.last_backup_label)
        
        # لیست بکاپ‌ها
        layout.add_widget(Label(
            text='📋 لیست بکاپ‌های موجود',
            size_hint_y=None,
            height=30,
            color=COLORS['text']
        ))
        
        scroll = ScrollView()
        self.backup_grid = GridLayout(cols=1, spacing=5, size_hint_y=None)
        self.backup_grid.bind(minimum_height=self.backup_grid.setter('height'))
        
        self.load_backup_list()
        
        scroll.add_widget(self.backup_grid)
        layout.add_widget(scroll)
        
        self.backup_status = Label(
            text='',
            size_hint_y=None,
            height=40,
            color=COLORS['success']
        )
        layout.add_widget(self.backup_status)
        
        return layout
    
    def load_backup_list(self):
        self.backup_grid.clear_widgets()
        backups = self.db.list_backups()
        
        if not backups:
            self.backup_grid.add_widget(Label(
                text='هیچ بکاپی یافت نشد',
                size_hint_y=None,
                height=50,
                color=COLORS['text_secondary']
            ))
            return
        
        # آپدیت آخرین بکاپ
        if backups:
            self.last_backup_label.text = f"📅 آخرین بکاپ: {backups[-1]['date']}"
        
        for backup in backups:
            card = BoxLayout(
                orientation='vertical',
                size_hint_y=None,
                height=100,
                padding=10,
                spacing=5
            )
            
            with card.canvas.before:
                Color(*[int(COLORS['surface'].lstrip('#')[i:i+2], 16)/255 for i in (0, 2, 4)])
                RoundedRectangle(size=card.size, pos=card.pos, radius=[5])
            
            info = f"📁 {backup['name']}\n📅 {backup['date']} | 💾 {backup['size']:.2f} MB"
            card.add_widget(Label(text=info, halign='right', color=COLORS['text']))
            
            btn_box = BoxLayout(size_hint_y=None, height=40, spacing=5)
            
            restore_btn = Button(
                text='🔄 بازیابی',
                size_hint=(0.5, 1),
                background_normal='',
                background_color=COLORS['success']
            )
            restore_btn.backup_name = backup['name']
            restore_btn.bind(on_press=self.restore_backup)
            btn_box.add_widget(restore_btn)
            
            delete_btn = Button(
                text='🗑 حذف',
                size_hint=(0.5, 1),
                background_normal='',
                background_color=COLORS['danger']
            )
            delete_btn.backup_name = backup['name']
            delete_btn.bind(on_press=self.delete_backup)
            btn_box.add_widget(delete_btn)
            
            card.add_widget(btn_box)
            self.backup_grid.add_widget(card)
    
    def manual_backup(self, instance):
        self.backup_status.text = '⏳ در حال ایجاد بکاپ و ارسال به تلگرام...'
        result = self.telegram_backup.create_backup_and_send(manual=True, shutdown=False)
        
        if result:
            self.backup_status.text = '✅ بکاپ ایجاد و به تلگرام ارسال شد'
            self.load_backup_list()
        else:
            self.backup_status.text = '❌ خطا در ایجاد بکاپ'
    
    def restore_backup(self, instance):
        backup_name = instance.backup_name
        
        content = BoxLayout(orientation='vertical', spacing=10)
        content.add_widget(Label(
            text='⚠️ هشدار!\nبا بازیابی بکاپ، همه اطلاعات فعلی از بین میروند.\nآیا مطمئن هستید؟',
            color=COLORS['text']
        ))
        
        btn_box = BoxLayout(size_hint_y=None, height=50, spacing=10)
        
        def confirm(btn):
            backup_path = os.path.join('backups', backup_name)
            success, current_backup = self.db.restore_backup(backup_path)
            
            if success:
                self.backup_status.text = f'✅ بازیابی موفق - بکاپ قبلی: {os.path.basename(current_backup)}'
                self.show_popup('✅ موفق', 'بازیابی با موفقیت انجام شد')
                self.load_backup_list()
            else:
                self.backup_status.text = '❌ خطا در بازیابی'
            
            popup.dismiss()
        
        def cancel(btn):
            popup.dismiss()
        
        confirm_btn = Button(
            text='بله، بازیابی کن',
            background_normal='',
            background_color=COLORS['danger']
        )
        confirm_btn.bind(on_press=confirm)
        
        cancel_btn = Button(
            text='خیر',
            background_normal='',
            background_color=COLORS['surface_light']
        )
        cancel_btn.bind(on_press=cancel)
        
        btn_box.add_widget(confirm_btn)
        btn_box.add_widget(cancel_btn)
        content.add_widget(btn_box)
        
        popup = Popup(
            title='تأیید بازیابی',
            title_color=COLORS['text'],
            content=content,
            size_hint=(0.8, 0.5)
        )
        popup.open()
    
    def delete_backup(self, instance):
        backup_name = instance.backup_name
        
        content = BoxLayout(orientation='vertical', spacing=10)
        content.add_widget(Label(text=f'آیا از حذف {backup_name} مطمئن هستید؟', color=COLORS['text']))
        
        btn_box = BoxLayout(size_hint_y=None, height=50, spacing=10)
        
        def confirm(btn):
            backup_path = os.path.join('backups', backup_name)
            if os.path.exists(backup_path):
                os.remove(backup_path)
                self.backup_status.text = f'✅ {backup_name} حذف شد'
                self.load_backup_list()
            popup.dismiss()
        
        def cancel(btn):
            popup.dismiss()
        
        confirm_btn = Button(
            text='بله، حذف کن',
            background_normal='',
            background_color=COLORS['danger']
        )
        confirm_btn.bind(on_press=confirm)
        
        cancel_btn = Button(
            text='خیر',
            background_normal='',
            background_color=COLORS['surface_light']
        )
        cancel_btn.bind(on_press=cancel)
        
        btn_box.add_widget(confirm_btn)
        btn_box.add_widget(cancel_btn)
        content.add_widget(btn_box)
        
        popup = Popup(
            title='تأیید حذف',
            title_color=COLORS['text'],
            content=content,
            size_hint=(0.8, 0.4)
        )
        popup.open()
    
    def refresh_backup_list(self, instance):
        self.load_backup_list()
        self.backup_status.text = '✅ لیست بروزرسانی شد'
    
    def do_logout(self, instance):
        self.manager.current = 'login'
    
    def show_popup(self, title, message):
        popup = Popup(
            title=title,
            title_color=COLORS['text'],
            content=Label(text=message, color=COLORS['text']),
            size_hint=(0.8, 0.4)
        )
        popup.open()

# ==================== کلاس اصلی برنامه ====================

class Amirho3inVPNApp(App):
    def build(self):
        self.title = APP_NAME
        self.lang = LanguageManager()
        self.theme = ThemeManager()
        
        # راه‌اندازی دیتابیس
        self.db_manager = DatabaseManager()
        
        # راه‌اندازی ارسال خودکار بکاپ به تلگرام
        self.telegram_backup = TelegramBackup(self.db_manager, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID)
        
        # راه‌اندازی هندلر سیگنال برای خاموشی تمیز
        self.signal_handler = SignalHandler(self.telegram_backup)
        
        # راه‌اندازی UpdateManager
        self.update_manager = UpdateManager(self)
        
        sm = ScreenManager()
        sm.add_widget(LoginScreen(name='login'))
        sm.add_widget(UserScreen(name='user'))
        sm.add_widget(AdminScreen(name='admin'))
        
        # چک کردن آپدیت بعد از ۳ ثانیه
        Clock.schedule_once(lambda dt: self.update_manager.check_for_update(), 3)
        
        # چک کردن مجدد هر ۲۴ ساعت
        Clock.schedule_interval(lambda dt: self.update_manager.check_for_update(), 86400)
        
        return sm

if __name__ == '__main__':
    Amirho3inVPNApp().run()
